
function saveprice(){

    let priceValue = document.getElementById('priceInput').value;

    console.log("Price:" + priceValue);
}


const { MongoClient } = require('mongodb'); // Import MongoClient from mongodb

// Your MongoDB connection URI
const uri = "mongodb+srv://a01742534:AihxmAeuAM6Z0fyo@clusteriot.prdo5q7.mongodb.net/?retryWrites=true&w=majority";

// Create a new MongoClient
const client = new MongoClient(uri, { useUnifiedTopology: true });

// Define an async function to update a document
async function updateDocument() {
    try {
        // Connect to the MongoDB cluster
        await client.connect();

        // Access the "Chatbot" database and "Productos" collection
        const myDB = client.db("Chatbot");
        const myColl = myDB.collection("Productos");

        // Define the filter for the document you want to update
        const filter = { Nombre: "Leche" };

        // Define the update operation using $set
        const updateDocument = {
            $set: {
                Precio: 5,
            },
        };

        // Use updateOne to update the document
        const result = await myColl.updateOne(filter, updateDocument);

        console.log(`Documento modificado: ${result.modifiedCount}`);
    } catch (error) {
        console.error('Error al actualizar el documento:', error);
    } finally {
        // Close the MongoDB connection when you're done
        await client.close();
    }
}

// Call the updateDocument function to perform the update
updateDocument();