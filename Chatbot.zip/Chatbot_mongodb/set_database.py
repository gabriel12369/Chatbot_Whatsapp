from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
import datetime as dt

#def check_conexion():
    # Send a ping to confirm a successful connection
    #try:
        #client.admin.command('ping')
        #print("Pinged your deployment. You successfully connected to MongoDB!")
    #except Exception as e:
        #print(e)

#Setting the client information
def set_dataCLient(name, tel, address, idClient, uri):
    client = MongoClient(uri, server_api=ServerApi('1'))
    mydb = client["ChatBot"]
    myclient = mydb["Cliente"]
    #Insertando la información del cliente en la tabla de Cliente
    orderClient = {
        "Id": idClient,
        "Nombre": name,
        "Telefono": tel,
        "Direccion": address
    }
    myclient.insert_one(orderClient)

#Setting the product information
def set_order(product, quantity, idClient, uri):
    client = MongoClient(uri, server_api=ServerApi('1'))
    mydb = client["ChatBot"]
    myorders = mydb["Pedidos"]
    #Insertando la información del pedido en la tabla de Pedidos
    order = {
        "Articulo": product,
        "Cantidad": quantity,
        "Id Cliente": idClient,
        "Fecha de pedido": str(dt.date.today())
    }
    myorders.insert_one(order)

#Updating the product stock
def update_database(name, quantity, uri):
    client = MongoClient(uri, server_api=ServerApi('1'))
    mydb = client["ChatBot"]
    myproducts = mydb["Productos"]
    #Actualizando el stock del producto
    ver= myproducts.find_one({"Nombre":name},{"_id":0,"Existencia": 1})
    stock = myproducts.find_one({"Nombre":name},{"_id":0,"Stock": 1})
    if stock["Stock"] - quantity >= 0 or ver["Existencia"] == True:
        myproducts.update_one({"Nombre":name},{"$set":{"Stock":stock["Stock"]-quantity}})
    
    else:
        myproducts.update_one({"Nombre":name},{"$set":{"Existencia":False}})
    
    
#Deleting the product from the order
def del_product(product, quantity, uri):
    client = MongoClient(uri, server_api=ServerApi('1'))
    mydb = client["ChatBot"]
    myorders = mydb["Pedidos"]
    myproducts = mydb["Productos"]
    #Eliminando el producto de la tabla de Pedidos y actualizando el stock
    stock = myproducts.find_one({"Nombre":product},{"_id":0,"Stock": 1})
    myproducts.update_one({"Nombre":product},{"$set":{"Stock":stock["Stock"]+quantity}})
    myorders.delete_one({"Articulo":product})
