from flask import Flask, jsonify, request
import services

app = Flask(__name__)

@app.route("/webhook/", methods=["GET"])
def webhook_whatsapp():
   #Si el token es igual al que recibimos
   if request.args.get('hub.verify_token') == "Carniceria":
      #Escribimos en el navegador el dato recibido desde facebook
      return request.args.get('hub.challenge')
   else:
      #Regresamos un mensaje de error
      return "Error de autenticación"

@app.route("/webhook/", methods=["POST"])
def get_message():
   #Recibimos todos los datos enviados en formato json
   data = request.get_json()

   #Extrayendo el número de teléfono y el mensaje
   telClient = data ['entry'][0]['changes'][0]['value']['messages'][0]['from']
   message = data['entry'][0]['changes'][0]['value']['messages'][0]['text']['body']

   #Extraemos el id del mensaje de whatsapp
   idM = data ['entry'][0]['changes'][0]['value']['messages'][0]['id']

   #Extraemos la hora del mensaje
   timeM = data ['entry'][0]['changes'][0]['value']['messages'][0]['timestamp']

   services.manageBot(telClient, message)

   return jsonify({"status": "succes"}, 200)

#INICIAMOS FLASK
if __name__ == "__main__":
  app.run(debug=True)
