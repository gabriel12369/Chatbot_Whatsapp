from heyoo import WhatsApp
import re
import set_database

uri = "mongodb+srv://a01742534:AihxmAeuAM6Z0fyo@clusteriot.prdo5q7.mongodb.net/?retryWrites=true&w=majority"

listMessage = []
cartProduct=[]
cartQuantity=[]
complete = False
idClient=0


def manageBot(tel, messageClient):
    #Si existe un mensaje
   if messageClient is not None:
      f = open("texto.txt", "w")
      f.write(messageClient)
      f.close()
      
      options(tel, messageClient.lower(), listMessage, cartProduct, cartQuantity, idClient, uri)

def send(telRec, answer):
   #Token temporal de acceso a facebook
   token = 'EAAYbadKS3uwBO0U4ZCCiEpRJ8w8kd4kfHJSOJHF6HR8mK91yAZBCdzmzHUmdHb6Qyx7ZB1eUZCYRYbJMlTlzZCv6mT51ulZAuB7wqLt9qZBZBeSE6sL9RXXZAzZCWkP8DeZABt1b1nunVqEflQehZA1ZCSRHrwOUq3hgGukZBjyqexojrcrQuv1GaZAqnpUZBTr3s2NKZBn8ZCVLqKQgKfFacJrppbTqYZD'

   #Identificador de número de teléfono
   idTel = '145034612031827'

   #Enviando mensajes
   messageWa = WhatsApp(token, idTel)
   telRec = telRec.replace("521", "52")

   messageWa.send_message(answer, telRec)

def options(telPerson, messageWa, listMessage, cartProduct, cartQuantity, idClient, uri):
    #Primer mensaje
    if "hola" in messageWa or "ola" in messageWa or "hol" in messageWa or "hols" in messageWa or "buenas" in messageWa or "buenos" in messageWa or "buen" in messageWa or "claro" in messageWa:
        listMessage.append(messageWa)
        botMessage = "Servicio a domicilio de las siguientes categorías: \n"
        botMessage = botMessage + "1.- Lácteos \n" + "2.- Carnes \n" + "3.- Frutería\n" + "4.-Abarrotes\n" 
        #Mandando mensaje al cliente
        send(telPerson,"Hola, buen día, soy el asistente de Butcher Shop y estoy para ayudarte a realizar tu compra, te recuerdo los servicios que ofrecemos: ")
        send(telPerson,botMessage)

    elif "si" in messageWa or "sí" in messageWa or "ok" in messageWa:
        listMessage.append(messageWa) #Guardando el mensaje del cliente en la lista
        botMessage = "1.- Lácteos \n" + "2.- Carnes \n" + "3.- Frutería\n" + "4.-Abarrotes\n"
        send(telPerson, botMessage)

    elif (("no" in messageWa or "nada" in messageWa or "para" in messageWa) and ("tano" not in messageWa)):
        #listMessage.clear()
        listMessage.append(messageWa)
        botMessage = "1.- Eliminar un producto\n" + "2.- Finalizar compra\n"
        send(telPerson, botMessage)

    #CATEGORÍA DE LÁCTEOS
    elif "lácteos" in messageWa or "lacteos" in messageWa or "lecteos" in messageWa or "lac" in messageWa or "lác" in messageWa or "teos" in messageWa:
        listMessage.append(messageWa)
        products = ["- Leche $25 (L)", "- Queso $80 (Kg)", "- Huevo $2.50 (pz)", "- Crema $10 (20 gr)", "- Mantequilla $15 (20 gr)"]
        response = "Has seleccionado Lácteos. Aquí tienes algunos productos disponibles:\n"
        response += "\n".join(products)
        send(telPerson, response)
     
        #Leche
    elif (("leche" in messageWa or "lech" in messageWa or "lec" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúanta leche desea?\n" + "Ingresa la cantidad en litros\n" + "Ejemplo: 1 litro o 2 litros"
        send(telPerson, response)

    elif "lec" in listMessage[-1]:
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] >= 1:
            listMessage.append(messageWa) 
            set_database.update_database("Leche", quantity[0], uri) #Actualizando el stock de la base datos de MongoDB
            cartProduct.append("leche") #Agregando el producto al carrito
            cartQuantity.append(str(quantity[0])+" litros") #Agregando la cantidad del producto al carrito
            set_database.set_order("Leche", quantity[0], idClient, uri) #Agregando la orden a la base de datos de MongoDB
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " litros de leche ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida, solamente puede ingresar 1 o más litros")

        #Queso
    elif (("queso" in messageWa or "que" in messageWa or "quesp" in messageWa) and ("cro" not in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2]) or listMessage[-2]==None):
        listMessage.append(messageWa)
        response = "¿Cúanto queso desea comprar?\n" + "Ingresa la cantidad en kg\n" + "Ejemplo: 1 kg o 0.5 kg"
        send(telPerson, response)

    elif "ques" in listMessage[-1] and "cro" not in listMessage[-1]:
        quantity = [float(s) for s in re.findall(r"-?\d+\.?\d*", messageWa)]
        if quantity[0] > -1:
            listMessage.append(messageWa)
            set_database.update_database("Queso", quantity[0], uri)
            cartProduct.append("queso")
            cartQuantity.append(str(quantity[0]) + " kg")
            set_database.set_order("Queso", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " kg de queso ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")
    
        #Huevo
    elif (("huevo" in messageWa or "huev" in messageWa or "hue" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2]) or listMessage[-2]==None):
        listMessage.append(messageWa)
        response = "¿Cúantos huevos desea comprar?\n" + "Ingresa la cantidad en piezas\n" + "Ejemplo: 1 pieza o 12 piezas"
        send(telPerson, response)
    
    elif "hue" in listMessage[-1]:
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] > 0:
            listMessage.append(messageWa)
            set_database.update_database("Huevo", quantity[0], uri)
            cartProduct.append("huevo")
            cartQuantity.append(str(quantity[0]) + " piezas")
            set_database.set_order("Huevo", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " piezas de huevo ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")
    
            #Crema
    elif (("crema" in messageWa or "crem" in messageWa or "cre" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2]) or listMessage[-2]==None):
        listMessage.append(messageWa)
        response = "¿Cúanta crema desea comprar?\n" + "Ingresa la cantidad en gramos\n" + "Ejemplo: 300 gramos o 250 gramos"
        send(telPerson, response)

    elif "cre" in listMessage[-1]:
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] > 0:
            listMessage.append(messageWa)
            set_database.update_database("Crema", quantity[0], uri)
            cartProduct.append("crema")
            cartQuantity.append(str(quantity[0]) + " gramos")
            set_database.set_order("Crema", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " gramos de crema ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")
    
            #Mantequilla
    elif (("mantequilla" in messageWa or "mantequi" in messageWa or "mante" in messageWa or "quilla" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúanta mantequilla desea comprar?\n" + "Ingresa la cantidad en gramos\n" + "Ejemplo: 20 gramos o 500 gramos"
        send(telPerson, response)

    elif "mante" in listMessage[-1] or "quilla" in listMessage[-1]:
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] > 0:
            listMessage.append(messageWa)
            set_database.update_database("Mantequilla", quantity[0], uri)
            cartProduct.append("mantequilla")
            cartQuantity.append(str(quantity[0]) + " gramos")
            set_database.set_order("Mantequilla", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " gramos de mantequilla ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")

    #CATEGORÍA DE CARNES
    elif "carnes" in messageWa or "nes" in messageWa or "carn" in messageWa and "res" not in messageWa and "puerco" not in messageWa:
        listMessage.append(messageWa)
        products = ["- Pollo $120 (Kg) ", "- Pescado $190 (kg)", "- Carne de res $180 (kg)", "- Carne de puerco $150 (Kg)", "- Chorizo $90 (Kg) "]
        response = "Has seleccionado Carnes. Aquí tienes algunos productos disponibles:\n"
        response += "\n".join(products)
        send(telPerson, response)

        #Pollo
    elif (("pollo" in messageWa or "pol" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúanto pollo desea comprar?\n" + "Ingresa la cantidad en kg\n" + "Ejemplo: 1 kg o 0.5 kg"
        send(telPerson, response)

    elif "pol" in listMessage[-1]:
        quantity = [float(s) for s in re.findall(r"-?\d+\.?\d*", messageWa)]
        if quantity[0] > -1:
            listMessage.append(messageWa)
            set_database.update_database("Pollo", quantity[0], uri) #Actualizando el stock de la base datos de MongoDB
            cartProduct.append("pollo") #Agregando el producto al carrito
            cartQuantity.append(str(quantity[0]) + " kg") #Agregando la cantidad del producto al carrito
            set_database.set_order("Pollo", quantity[0], idClient, uri) #Agregando la orden a la base de datos de MongoDB
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " kg de pollo ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")
    
        #Pescado
    elif (("pescado" in messageWa or "pes" in messageWa or "cado" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúanto pescado desea comprar?\n" + "Ingresa la cantidad en kg\n" + "Ejemplo: 1 kg o 1.5 kg"
        send(telPerson, response)

    elif "pes" in listMessage[-1] or "cado" in listMessage[-1]:
        quantity = [float(s) for s in re.findall(r"-?\d+\.?\d*", messageWa)]
        if quantity[0] > -1:
            listMessage.append(messageWa)
            set_database.update_database("Pescado", quantity[0], uri)
            cartProduct.append("pescado")
            cartQuantity.append(str(quantity[0]) + " kg")
            set_database.set_order("Pescado", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " kg de pescado ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")
    
        #Carne de res
    elif (("carne de res" in messageWa or "res" in messageWa and "fres" not in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúanto carne de res desea comprar?\n" + "Ingresa la cantidad en kg\n" + "Ejemplo: 1 kg o 2.5 kg"
        send(telPerson, response)

    elif "res" in listMessage[-1] and "fres" not in listMessage[-1]:
        quantity = [float(s) for s in re.findall(r"-?\d+\.?\d*", messageWa)]
        if quantity[0] > -1:
            listMessage.append(messageWa) 
            set_database.update_database("Carne de res", quantity[0], uri)
            cartProduct.append("carne de res")
            cartQuantity.append(str(quantity[0]) + " kg")
            set_database.set_order("Carne de res", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " kg de carne de res ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")
    
        #Carne de puerco
    elif (("carne de puerco" in messageWa or "puerco" in messageWa or "puer" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúanto carne de puerco desea comprar?\n" + "Ingresa la cantidad en kg\n" + "Ejemplo: 1 kg o 3.5 kg"
        send(telPerson, response)

    elif "puerco" in listMessage[-1] or "puer" in listMessage[-1]:
        quantity = [float(s) for s in re.findall(r"-?\d+\.?\d*", messageWa)]
        if quantity[0] > -1:
            listMessage.append(messageWa) 
            set_database.update_database("Carne de puerco", quantity[0],uri)
            cartProduct.append("carne de puerco")
            cartQuantity.append(str(quantity[0]) + " kg")
            set_database.set_order("Carne de puerco", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " kg de carne de puerco ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")
    
        #Chorizo
    elif (("chorizo" in messageWa or "chor" in messageWa or "rizo" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúanto chorizo desea comprar?\n" + "Ingresa la cantidad en kg\n" + "Ejemplo: 1 kg o 0.5 kg"
        send(telPerson, response)

    elif "chor" in listMessage[-1] or "rizo" in listMessage[-1]:
        quantity = [float(s) for s in re.findall(r"-?\d+\.?\d*", messageWa)]
        if quantity[0] > -1:
            listMessage.append(messageWa)
            set_database.update_database("Chorizo", quantity[0], uri)
            cartProduct.append("chorizo")
            cartQuantity.append(str(quantity[0]) + " kg")
            set_database.set_order("Chorizo", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " kg de chorizo ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")

    #CATEGORÍA DE FRUTERÍA
    elif "frutería" in messageWa or "Fruteria" in messageWa or "frut" in messageWa:
        listMessage.append(messageWa)
        products = ["- Limón $25 (kg)", "- Tomate $28 (Kg) ", "- Cebolla $35 (Kg)", "- Naranja $40 (Kg)", "- Manzana $50 (Kg) ", "- Plátano $18 (pz)"]
        response = "Has seleccionado Frutería. Aquí tienes algunos productos disponibles:\n"
        response += "\n".join(products)
        send(telPerson, response)

        #Limón
    elif (("limón" in messageWa or "limon" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúanto limón desea comprar?\n" + "Ingresa la cantidad en kg o en piezas\n" + "Ejemplo: 1 kg o 10 piezas"
        send(telPerson, response)

    elif (("limon" in listMessage[-1] or "limón" in listMessage[-1]) and ("pie" in messageWa)):
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] > 0:
            listMessage.append(messageWa) 
            set_database.update_database("Limón", 0.076*quantity[0], uri) #Actualizando el stock de la base datos de MongoDB
            cartProduct.append("limón")  #Agregando el producto al carrito
            cartQuantity.append(str(quantity[0]) + " piezas") #Agregando la cantidad del producto al carrito
            set_database.set_order("Limón", 0.076*quantity[0], idClient, uri) #Agregando la orden a la base de datos de MongoDB
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " limones ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")

    elif "lim" in listMessage[-1] and "kg" in messageWa:
        quantity = [float(s) for s in re.findall(r"-?\d+\.?\d*", messageWa)]
        if quantity[0] > -1:
            listMessage.append(messageWa)
            set_database.update_database("Limón", quantity[0], uri)
            cartProduct.append("limón")
            cartQuantity.append(str(quantity[0]) + " kg")
            set_database.set_order("Limón", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " kg de limón ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")

        #Tomate
    elif (("tomate" in messageWa or "tom" in messageWa or "mate" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúanto tomate desea comprar?\n" + "Ingresa la cantidad en kg o en piezas\n" + "Ejemplo: 1 kg o 3 piezas"
        send(telPerson, response)
    
    elif (("tom" in listMessage[-1] or "mate" in listMessage[-1]) and ("pie" in messageWa)):
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] > 0:
            listMessage.append(messageWa)
            set_database.update_database("Tomate", 0.200*quantity[0], uri)
            cartProduct.append("tomate")
            cartQuantity.append(str(quantity[0]) + " piezas")
            set_database.set_order("Tomate", 0.200*quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " tomates ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")

    elif (("tom" in listMessage[-1] or "mate" in listMessage[-1]) and ("kg" in messageWa)):
        quantity = [float(s) for s in re.findall(r"-?\d+\.?\d*", messageWa)]
        if quantity[0] > -1:
            listMessage.append(messageWa)
            set_database.update_database("Tomate", quantity[0], uri)
            cartProduct.append("tomate")
            cartQuantity.append(str(quantity[0]) + " kg")
            set_database.set_order("Tomate", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " kg de tomate ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")

        #Cebolla
    elif (("cebolla" in messageWa or "ceb" in messageWa or "olla" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúanto cebolla desea comprar?\n" + "Ingresa la cantidad en kg o en piezas\n" + "Ejemplo: 1 kg o 3 piezas"
        send(telPerson, response)

    elif (("ceb" in listMessage[-1] or "olla" in listMessage[-1]) and ("pie" in messageWa)):
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] > 0:
            listMessage.append(messageWa) 
            set_database.update_database("Cebolla", 0.300*quantity[0], uri)
            cartProduct.append("cebolla")
            cartQuantity.append(str(quantity[0]) + " piezas")
            set_database.set_order("Cebolla", 0.300*quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " cebollas ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")
    
    elif (("ceb" in listMessage[-1] or "olla" in listMessage[-1]) and ("kg" in messageWa)):
        quantity = [float(s) for s in re.findall(r"-?\d+\.?\d*", messageWa)]
        if quantity[0] > -1:
            listMessage.append(messageWa)
            set_database.update_database("Cebolla", quantity[0], uri)
            cartProduct.append("cebolla")
            cartQuantity.append(str(quantity[0]) + " kg")
            set_database.set_order("Cebolla", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " kg de cebolla ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")

        #Naranja
    elif ((("naranja" in messageWa or "nar" in messageWa or "anja" in messageWa) and ("jug" not in messageWa and "elim" not in messageWa)) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúanto naranja desea comprar?\n" + "Ingresa la cantidad en kg o en piezas\n" + "Ejemplo: 1 kg o 5 piezas"
        send(telPerson, response)

    elif (("nar" in listMessage[-1] or "anja" in listMessage[-1]) and ("jug" not in listMessage[-1] and "elim" not in listMessage[-1]) and ("pie" in messageWa)):
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] > 0:
            listMessage.append(messageWa)
            set_database.update_database("Naranja", 0.250*quantity[0], uri)
            cartProduct.append("naranja")
            cartQuantity.append(str(quantity[0]) + " piezas")
            set_database.set_order("Naranja", 0.250*quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " naranjas ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")

    elif (("nar" in listMessage[-1] or "anja" in listMessage[-1]) and ("jug" not in listMessage[-1] and "elim" not in listMessage[-1]) and ("kg" in messageWa)):
        quantity = [float(s) for s in re.findall(r"-?\d+\.?\d*", messageWa)]
        if quantity[0] > -1:
            listMessage.append(messageWa)
            set_database.update_database("Naranja", quantity[0], uri)
            #if status == True:
            cartProduct.append("naranja")
            cartQuantity.append(str(quantity[0]) + " kg")
            set_database.set_order("Naranja", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " kg de naranja ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")

        #Manzana
    elif (("manzana" in messageWa or "manz" in messageWa or "ana" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúanto manzana desea comprar?\n" + "Ingresa la cantidad en kg o en piezas\n" + "Ejemplo: 1 kg o 5 piezas"
        send(telPerson, response)

    elif (("manz" in listMessage[-1] or "ana" in listMessage[-1]) and ("pie" in messageWa)):
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] > 0:
            listMessage.append(messageWa)
            set_database.update_database("Manzana", 0.180*quantity[0], uri)
            cartProduct.append("manzana")
            cartQuantity.append(str(quantity[0]) + " piezas")
            set_database.set_order("Manzana", 0.180*quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " manzanas ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")
    
    elif (("manz" in listMessage[-1] or "ana" in listMessage[-1]) and ("kg" in messageWa)):
        quantity = [float(s) for s in re.findall(r"-?\d+\.?\d*", messageWa)]
        if quantity[0] > -1:
            listMessage.append(messageWa)
            set_database.update_database("Manzana", quantity[0], uri)
            cartProduct.append("manzana")
            cartQuantity.append(str(quantity[0]) + " kg")
            set_database.set_order("Manzana", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " kg de manzana ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")

        #Plátano
    elif (("plátano" in messageWa or "plát" in messageWa or "plat" in messageWa or "tano" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúanto plátano desea comprar?\n" + "Ingresa la cantidad en kg o en piezas\n" + "Ejemplo: 1 kg o 5 piezas"
        send(telPerson, response)

    elif (("plát" in listMessage[-1] or "plat" in listMessage[-1] or "tano" in listMessage[-1]) and ("pie" in messageWa)):
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] > 0:
            listMessage.append(messageWa) 
            set_database.update_database("Plátano", 0.150*quantity[0], uri)
            cartProduct.append("plátano")
            cartQuantity.append(str(quantity[0]) + " piezas")
            set_database.set_order("Plátano", 0.150*quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " plátanos ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")
    
    elif (("plát" in listMessage[-1] or "plat" in listMessage[-1] or "tano" in listMessage[-1]) and ("kg" in messageWa)):
        quantity = [float(s) for s in re.findall(r"-?\d+\.?\d*", messageWa)]
        if quantity[0] > -1:
            listMessage.append(messageWa)
            set_database.update_database("Plátano", quantity[0], uri)
            cartProduct.append("plátano")
            cartQuantity.append(str(quantity[0]) + " kg")
            set_database.set_order("Plátano", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " kg de plátano ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")

    #CATETORÍA DE ABARROTES
    elif "abarrotes " in messageWa or "abar" in messageWa or "rotes" in messageWa:
        listMessage.append(messageWa)
        products = ["- Aceite $45 (Lt)", "- Jabón $35 (Kg)", "- Croquetas $5 (10 gr)", "- Refresco $15 (1/2 Lt)", "- Jugo de naranaja $35 (Lt)", "- Garrafón de agua $25 (20 Lt)"] 
        response = "Has seleccionado Abarrotes. Aquí tienes algunos productos disponibles:\n"
        response += "\n".join(products)
        send(telPerson, response)

        #Aceite
    elif (("aceite" in messageWa or "ace" in messageWa or "eite" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúantas envases de aceite desea comprar?\n" + "Ingresa la cantidad en piezas\n" + "Ejemplo: 1 envase o 2 botellas"
        send(telPerson, response)

    elif (("ace" in listMessage[-1] or "eite" in listMessage[-1]) and ("bote" in messageWa or "ellas" in messageWa or "env" in messageWa or "ase" in messageWa)):
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] >= 1:
            listMessage.append(messageWa) 
            set_database.update_database("Aceite", quantity[0], uri) #Actualizando el stock de la base datos de MongoDB
            cartProduct.append("aceite") #Agregando el producto al carrito
            cartQuantity.append(str(quantity[0]) + " envases") #Agregando la cantidad del producto al carrito
            set_database.set_order("Aceite", quantity[0], idClient, uri) #Agregando la orden a la base de datos de MongoDB
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " envases de aceite ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")

        #Jabón
    elif (("jabón" in messageWa or "jab" in messageWa or "bón" in messageWa or "bon" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúantas piezas de jabón desea comprar?\n" + "Ingresa la cantidad en piezas\n" + "Ejemplo: 1 envase o 2 piezas"
        send(telPerson, response)

    elif (("jab" in listMessage[-1] or "bón" in listMessage[-1] or "bon" in listMessage[-1]) and ("pie" in messageWa or "env" in messageWa)):
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] >= 1:
            listMessage.append(messageWa)
            set_database.update_database("Jabón", quantity[0], uri)
            cartProduct.append("jabón")
            cartQuantity.append(str(quantity[0]) + " piezas")
            set_database.set_order("Jabón", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " piezas de jabón ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")
    
        #Croquetas
    elif (("croquetas" in messageWa or "cro" in messageWa or "quetas" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúantas croquetas desea comprar?\n" + "Ingresa la cantidad en gramos\n" + "Ejemplo: 50 gramos o 100 gramos"
        send(telPerson, response)

    elif "cro" in listMessage[-1] or "quetas" in listMessage[-1] and "gram" in messageWa:
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] >= 1:
            listMessage.append(messageWa) 
            set_database.update_database("Croquetas", quantity[0], uri)
            cartProduct.append("croquetas")
            cartQuantity.append(str(quantity[0]) + " gramos")
            set_database.set_order("Croquetas", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " gramos de croquetas ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")
    
        #Refresco
    elif (("refresco" in messageWa or "refr" in messageWa or "esco" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúantos refrescos desea comprar?\n" + "Ingresa la cantidad en piezas\n" + "Ejemplo: 1 envase o 2 botellas"
        send(telPerson, response)

    elif (("refr" in listMessage[-1] or "esco" in listMessage[-1]) and ("bote" in messageWa or "ellas" in messageWa or "env" in messageWa or "ase" in messageWa)):
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] >= 1:
            listMessage.append(messageWa)
            set_database.update_database("Refresco", quantity[0], uri)
            cartProduct.append("refresco")
            cartQuantity.append(str(quantity[0]) + " envases")
            set_database.set_order("Refresco", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " envases de refresco ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")
    
        #Jugo de naranja
    elif (("jugo de naranja" in messageWa or "jugo" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúantos envases de jugo de naranja desea comprar?\n" + "Ingresa la cantidad en piezas\n" + "Ejemplo: 1 envase o 2 botellas"
        send(telPerson, response)

    elif (("jugo" in listMessage[-1]) and ("bote" in messageWa or "ellas" in messageWa or "env" in messageWa or "ase" in messageWa)):
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] >= 1:
            listMessage.append(messageWa)
            set_database.update_database("Jugo de naranja", quantity[0], uri)
            cartProduct.append("jugo de naranja")
            cartQuantity.append(str(quantity[0]) + " envases")
            set_database.set_order("Jugo de naranja", quantity[0], idClient, uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " envases de jugo de naranja ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")
    
        #Garrafón de agua
    elif (("garrafón de agua" in messageWa or "agua" in messageWa) and ("elim" not in listMessage[-1]) and ("fin" not in listMessage[-2] or listMessage[-2]==None)):
        listMessage.append(messageWa)
        response = "¿Cúantos garrafones de agua desea comprar?\n" + "Ingresa la cantidad en piezas\n" + "Ejemplo: 1 garrafón o 2 garrafones"
        send(telPerson, response)

    elif (("garrafón" in listMessage[-1] or "garra" in listMessage[-1] or "agua" in listMessage[-1]) and ("garra" in messageWa or "ones" in messageWa or "fón" in messageWa)):
        quantity = [int(temp) for temp in messageWa.split() if temp.isdigit()]
        if quantity[0] >= 1:
            listMessage.append(messageWa)
            set_database.update_database("Garrafón de agua", quantity[0], uri)
            cartProduct.append("garrafón de agua")
            cartQuantity.append(str(quantity[0]) + " garrafones")
            set_database.set_order("Garrafón de agua", quantity[0], idClient,  uri)
            send(telPerson, "Tu pedido de " + str(quantity[0]) + " garrafones de agua ha sido registrado")
            send(telPerson, "¿Desea agregar otro producto?")
        else:
            send(telPerson, "Ingresa una cantidad válida")

    #ELIMINAR UN PRODUCTO
    elif (("eliminar un producto" in messageWa or "elim" in messageWa or "prod" in messageWa) or (("elim" in listMessage[-2] or "prod" in listMessage[-2]) and ("si" in messageWa or "sí" in messageWa or "ok" in messageWa))):
        listMessage.append(messageWa)
        response = "¿Qué producto deseas eliminar?\n"
        response += "\n".join(cartProduct)
        response += "\n\nNota: Ingresa solamente el nombre del producto\n" + "Ejemplo: leche o carne de res"
        send(telPerson, response)

    elif "elim" in listMessage[-1] or "prod" in listMessage[-1]:
        listMessage.append(messageWa)
        #Eliminando el producto de la base de datos
        set_database.del_product(messageWa, cartQuantity[cartProduct.index(messageWa)], uri)
        #Eliminando el producto del carrito
        cartQuantity.pop(cartProduct.index(messageWa))
        #Eliminando la cantidad del carrito
        cartProduct.remove(messageWa)
        send(telPerson, "El producto " + messageWa + " ha sido eliminado")
        send(telPerson, "¿Desea eliminar otro producto?")

    #FINALIZAR COMPRA
    elif "finalizar compra" in messageWa or "fin" in messageWa or "compra" in messageWa:
        listMessage.append(messageWa)
        #Pidiendo el nombre al cliente
        send(telPerson, "Para finalizar la compra ingrese su nombre\n")

    elif "fin" in listMessage[-1]:
        listMessage.append(messageWa)
        #Pidiendo la dirección al cliente
        send(telPerson, "Muy bien")
        send(telPerson, "Ingrese la dirección de entrega")

    elif "fin" in listMessage[-2]:
        listMessage.append(messageWa)
        #Mandando los datos del cliente a la base de datos
        set_database.set_dataCLient(listMessage[-2], str(telPerson), listMessage[-1], idClient, uri)
        idClient += 1
        #Mensaje de despedida
        send(telPerson, "Gracias por su compra " + listMessage[-2] + " su pedido será entregado en 20 minutos")
        send(telPerson, "El pago puede ser en efectivo o con tarjeta y será realizado al momento de la entrega")
        send(telPerson, "Que tenga buen día")

    #Si no se ingresa una opción válida
    else:
        listMessage.append(messageWa)
        send(telPerson, "No te entendí, ¿puedes repetirlo de otra manera?")